from django.apps import AppConfig


class CodigoConfig(AppConfig):
    name = 'codigo'
